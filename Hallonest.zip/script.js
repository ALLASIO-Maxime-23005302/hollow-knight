function noir() {
  var element = document.body;
  element.classList.toggle("dark-mode");
}
function blanc() {
  var element = document.body;
  element.classList.toggle("light-mode");
}
function rose() {
  var element = document.body;
  element.classList.toggle("pink-mode");
}
function bleu() {
  var element = document.body;
  element.classList.toggle("blue-mode");
}
function vert() {
  var element = document.body;
  element.classList.toggle("green-mode");
}
function jaune() {
  var element = document.body;
  element.classList.toggle("yellow-mode");
}